package pe.edu.vallegrande.app.models;

public class Product {
    private int id;
    private String code;
    private String Amount;
    private String Details_Goods;
    private String Admission_date;
    private String date_depreciation;
    private String state;
    private String area_id;

    public Product(String code2, String Amount, String Details_Goods, String Admission_date, String state, String area_id) {
        this.code = code;
        this.Amount = Amount;
        this.Details_Goods = Details_Goods;
        this.Admission_date = Admission_date;
        this.date_depreciation = date_depreciation;
        this.state = state;
        this.area_id = area_id;
    }

    // Getters and Setters


	public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return Amount;
    }

    public void setName(String Amount) {
        this.Amount = Amount;
    }

    public String getPrice() {
        return Details_Goods;
    }

    public void setPrice(String Details_Goods) {
        this.Details_Goods = Details_Goods;
    }

    public String getDescription() {
        return Admission_date;
    }

    public void setDescription(String Admission_date) {
        this.Admission_date = Admission_date

    public String getStatus() {
        return date_depreciation;
    }

    public void setStatus(String date_depreciation) {
        this.date_depreciation = date_depreciation;
    }

    public String getStoreType() {
        return state;
    }

    public void setStoreType(String storeType) {
        this.state = state;
    }

    @Override
    public String toString() {
        return "Product [" + id + ", " + Amount + ", " + Details_Goods + ", " + Admission_date +
                ", " + state + ", " + area_id + "]";
        
    }

	public String getdetails_Goods() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
